var version = '2.0.3'

function check_ocr() {
	$("#state_button").attr("class", "mini ui loading button");
	$.ajax({
		type: "GET", 
		cache: false, 
		url: "http:///127.0.0.1:11451/check", 
		data: "", 
		success: function() {
			$("#state_text").text("OCR Server状态：可用");
			$("#state_button").attr("class", "mini ui button");
			$("#close_button").attr("class", "mini ui icon button");
		}, 
		error: function() {
			$("#state_text").text("OCR Server状态：不可用");
			$("#state_button").attr("class", "mini ui button");
			$("#close_button").attr("class", "mini ui disabled icon button");
		}
	});
}
check_ocr();
$("#state_button").click(check_ocr);
$("#close_button").click(function() {
	$.get("http:///127.0.0.1:11451/exit");
});

function check_update() {
	$("#update_button").attr("class", "mini ui loading button");
	$.ajax({
		type: "GET", 
		cache: false, 
		url: "https://api.github.com/repos/xgugugu/cdtplus/releases/latest", 
		success: function(json) {
			if (json.name != version) {
				$("#update_text").after('<a target="_blank" href="' + json.assets[0].browser_download_url + '">' + json.name + '</a>');
				$("#update_text").remove();
				$("#update_button").attr("class", "mini ui button");
			} else {
				$("#update_text").text('无更新');
				$("#update_button").attr("class", "mini ui button");
			}
		}, 
		error: function() {
			$("#update_text").text("检测失败");
			$("#update_button").attr("class", "mini ui button");
		}
	});
}
check_update();
$("#update_button").click(check_update);
