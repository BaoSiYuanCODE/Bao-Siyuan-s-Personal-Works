#include<bits/stdc++.h>
#include<windows.h>
using namespace std;
ifstream fin;
ofstream fout;
int a,b,c,d;
int main(){
	fout.open("Non-system-level_C++_programming_compiler_API_code.cppapi");
	string code,input;
	bool read=true;
	while(getline(cin,code)){
		if(read){
			if(code=="EOF-0x3f3f3f3f"){
				read=!read;
				fout<<"This is the end of the C++_code,please exit,@compiler_API/exe."<<endl;
				system("cls");
			}
			else fout<<code<<endl;
		}
		else{
			input=code;
			fout<<input<<endl;
		}
	}
	fout<<"This is the end of the code_input,please exit,@compiler_API/exe.";
	fout.close();
	system("cls");
	ShellExecute(NULL,"open","��ϵͳ��C++��̱�����_compiler_API.exe",NULL,NULL,SW_HIDE);
	Sleep(4000);
	fin.open("Non-system-level_C++_programming_compiler_API_result.cppapi");
	string result;
	while(true){
		getline(fin,result);
		cout<<result<<endl;
		if(result=="Stats:")break;
	}
	getline(fin,result);
	cout<<result;
	fin.close();
	remove("Non-system-level_C++_programming_compiler_API_code.cppapi");
	remove("Non-system-level_C++_programming_compiler_API_result.cppapi");
	return 0;
}
