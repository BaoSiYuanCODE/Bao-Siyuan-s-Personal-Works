#include<bits/stdc++.h>
#include<windows.h>
using namespace std;
namespace syccc_library{
	ifstream sfin;
	ofstream sfout;
	string wts(string wz){
		sfout.open("syccc_library_input.txt");
		sfout<<1<<endl<<wz;
		sfout.close();
		ShellExecute(NULL,"open","syccc�����.exe",NULL,NULL,SW_HIDE);
		Sleep(80);
		string sb;
		sfin.open("syccc_library_output.txt");
		sfin>>sb;
		sfin.close();
		remove("syccc_library_input.txt");
		remove("syccc_library_output.txt");
		return sb;
	}
	string stw(string sb){
		sfout.open("syccc_library_input.txt");
		sfout<<2<<endl<<sb;
		sfout.close();
		ShellExecute(NULL,"open","syccc�����.exe",NULL,NULL,SW_HIDE);
		Sleep(80);
		string wz;
		sfin.open("syccc_library_output.txt");
		sfin>>wz;
		sfin.close();
		remove("syccc_library_input.txt");
		remove("syccc_library_output.txt");
		return wz;
	}
}
using namespace syccc_library;
/*
�����б���
1. string wts(string wz)   ����wz ���� ��Ӧ��syccc����
2. string stw(string sb)   ����sb syccc���� ��Ӧ������
*/
int main(){
	string wz,sb;
	cin>>wz;
	sb=wts(wz);
	cout<<sb;
	return 0;
}
